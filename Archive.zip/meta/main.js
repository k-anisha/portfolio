import * as d3 from "https://cdn.jsdelivr.net/npm/d3@7.9.0/+esm";

async function loadData() {
    const data = await d3.csv("loc.csv", (row) => ({
        ...row,
        line: Number(row.line),
        depth: Number(row.depth),
        length: Number(row.length),
        date: new Date(row.date + "T00:00" + row.timezone),
        datetime: new Date(row.datetime),
    }));

    return data;
}

function processCommits(data) {
    return d3
        .groups(data, (d) => d.commit)
        .map(([commit, lines]) => {
            let first = lines[0];
            let { author, date, time, timezone, datetime } = first;

            let ret = {
                id: commit,
                url: "https://github.com/vis-society/lab-7/commit/" + commit,
                author,
                date,
                time,
                timezone,
                datetime,
                hourFrac: datetime.getHours() + datetime.getMinutes() / 60,
                totalLines: lines.length,
            };

            Object.defineProperty(ret, "lines", {
                value: lines,
                writable: true,
                configurable: true,
                enumerable: false,
            });

            return ret;
        });
}

const data = await loadData();
const commits = processCommits(data);

console.log(commits);

function renderCommitInfo(data, commits) {
    const dl = d3.select("#stats").append("dl").attr("class", "stats");

    dl.append("dt").html("Total <abbr title='Lines of code'>LOC</abbr>");
    dl.append("dd").text(data.length);

    dl.append("dt").text("Total commits");
    dl.append("dd").text(commits.length);

    let maxFileLength = d3.max(commits, (d) => d.totalLines);

    dl.append("dt").text("Max file length");
    dl.append("dd").text(maxFileLength);

    dl.append("dt").text("Average file length");
    dl.append("dd").text(Math.round(data.length / commits.length));
}

renderCommitInfo(data, commits);